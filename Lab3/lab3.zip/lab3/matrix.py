# takes the number of rows and columns and makes a matrix of those dimensions
def make_matrix(r, c)
	raise ValueError("todo")

# takes two matrices and multiplies them returnin the resulting matrix
def matrixmult(a,b):
	raise ValueError("todo")

# prints the given matrix, mostly for testing purposes
def print_matrix(m):
	raise ValueError("todo")

# given a state matrix, and a transition matrix, runs a markov simulation of the game and returns average number of moves.  
def markov_simulation():
	raise ValueError("todo")